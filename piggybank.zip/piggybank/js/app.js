/* =========================================================
   CELENGAN — app.js
   Data disimpan di localStorage (key: "piggy_banks"), berupa
   array of:
   {
     id, name, image (dataURL), target, dailyAmount,
     days: [...], time, createdAt, currentTotal,
     history: [{ id, timestamp, amount, reason }]
   }
   ========================================================= */

(function () {
  "use strict";

  const STORAGE_KEY = "piggy_banks";
  const DAY_NAMES = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const MONTH_NAMES = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  // Capacitor LocalNotifications pakai weekday 1=Minggu ... 7=Sabtu
  const CAP_WEEKDAY = { Minggu: 1, Senin: 2, Selasa: 3, Rabu: 4, Kamis: 5, Jumat: 6, Sabtu: 7 };

  function loadGoals() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function saveGoals(goals) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(goals));
  }

  function formatRupiah(n) {
    const num = Number(n) || 0;
    return "Rp" + num.toLocaleString("id-ID");
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function formatDateLong(timestamp) {
    if (!timestamp) return "-";
    const d = new Date(timestamp);
    return d.getDate() + ", " + MONTH_NAMES[d.getMonth()] + ", " + d.getFullYear();
  }

  // Hitung perkiraan tanggal tabungan selesai: jalan hari demi hari dari
  // tanggal dibuat, hanya menambah "menabung perhari" pada hari yang
  // dipilih (kalau tidak pilih hari sama sekali, dianggap tiap hari),
  // sampai totalnya mencapai target.
  function computeEstimatedCompletion(createdAt, target, dailyAmount, days) {
    if (!dailyAmount || dailyAmount <= 0 || !target || target <= 0) return null;
    const activeDays = days && days.length ? days : DAY_NAMES.slice();
    const cursor = new Date(createdAt);
    cursor.setHours(0, 0, 0, 0);
    let total = 0;
    for (let i = 0; i < 3660; i++) {
      const dayName = DAY_NAMES[cursor.getDay()];
      if (activeDays.includes(dayName)) {
        total += dailyAmount;
        if (total >= target) return cursor.getTime();
      }
      cursor.setDate(cursor.getDate() + 1);
    }
    return null; // lebih dari ~10 tahun, tidak dihitung
  }

  // Format input angka jadi bertitik ribuan saat mengetik (mis. 1000 -> 1.000)
  function attachThousandFormatting(el) {
    el.addEventListener("input", () => {
      const digits = el.value.replace(/\D/g, "");
      el.value = digits ? Number(digits).toLocaleString("id-ID") : "";
    });
  }

  function parseFormattedNumber(el) {
    return Number(el.value.replace(/\D/g, "")) || 0;
  }

  // ---------- SCREEN NAVIGATION ----------
  const screenHome = document.getElementById("screen-home");
  const screenCreate = document.getElementById("screen-create");
  const screenDetail = document.getElementById("screen-detail");

  function showScreen(screen) {
    [screenHome, screenCreate, screenDetail].forEach((s) => s.classList.add("hidden"));
    screen.classList.remove("hidden");
  }

  // ---------- HOME: RENDER LIST ----------
  const savingsList = document.getElementById("savings-list");
  const emptyState = document.getElementById("empty-state");

  function renderHome() {
    const goals = loadGoals();
    savingsList.innerHTML = "";

    if (goals.length === 0) {
      emptyState.classList.remove("hidden");
      return;
    }
    emptyState.classList.add("hidden");

    goals.forEach((g) => {
      const pct = g.target > 0 ? Math.min(100, Math.round((g.currentTotal / g.target) * 100)) : 0;

      const card = document.createElement("div");
      card.className = "saving-card";
      card.innerHTML = `
        <img class="saving-card-thumb" src="${g.image || ""}" alt="">
        <div class="saving-card-body">
          <div class="saving-card-name">${escapeHtml(g.name)}</div>
          <div class="saving-card-amounts">${formatRupiah(g.currentTotal)} / ${formatRupiah(g.target)}</div>
          <div class="saving-card-track"><div class="saving-card-track-fill" style="width:${pct}%"></div></div>
        </div>
      `;
      card.addEventListener("click", () => openDetail(g.id));
      savingsList.appendChild(card);
    });
  }

  function escapeHtml(str) {
    const d = document.createElement("div");
    d.textContent = str == null ? "" : String(str);
    return d.innerHTML;
  }

  document.getElementById("open-create-btn").addEventListener("click", () => {
    resetCreateForm();
    showScreen(screenCreate);
  });

  // ---------- CREATE FORM ----------
  const imageUploadBox = document.getElementById("image-upload-box");
  const imageInput = document.getElementById("image-input");
  const imagePreview = document.getElementById("image-preview");
  const imagePlaceholder = document.getElementById("image-placeholder");
  const inputName = document.getElementById("input-name");
  const inputTarget = document.getElementById("input-target");
  const inputDaily = document.getElementById("input-daily");
  const inputTime = document.getElementById("input-time");
  const dayGrid = document.getElementById("day-grid");
  const createMsg = document.getElementById("create-msg");
  const submitCreateBtn = document.getElementById("submit-create-btn");

  let selectedDays = [];
  let selectedImageData = "";

  attachThousandFormatting(inputTarget);
  attachThousandFormatting(inputDaily);

  function resetCreateForm() {
    inputName.value = "";
    inputTarget.value = "";
    inputDaily.value = "";
    inputTime.value = "";
    selectedDays = [];
    selectedImageData = "";
    imagePreview.src = "";
    imagePreview.classList.add("hidden");
    imagePlaceholder.classList.remove("hidden");
    createMsg.textContent = "";
    createMsg.className = "field-msg";
    dayGrid.querySelectorAll(".day-btn").forEach((b) => b.classList.remove("active"));
  }

  imageUploadBox.addEventListener("click", () => imageInput.click());

  imageInput.addEventListener("change", () => {
    const file = imageInput.files && imageInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      selectedImageData = reader.result;
      imagePreview.src = selectedImageData;
      imagePreview.classList.remove("hidden");
      imagePlaceholder.classList.add("hidden");
    };
    reader.readAsDataURL(file);
  });

  dayGrid.querySelectorAll(".day-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const day = btn.dataset.day;
      if (selectedDays.includes(day)) {
        selectedDays = selectedDays.filter((d) => d !== day);
        btn.classList.remove("active");
      } else {
        selectedDays.push(day);
        btn.classList.add("active");
      }
    });
  });

  document.getElementById("create-back-btn").addEventListener("click", () => showScreen(screenHome));

  submitCreateBtn.addEventListener("click", () => {
    const name = inputName.value.trim();
    const target = parseFormattedNumber(inputTarget);
    const daily = parseFormattedNumber(inputDaily);

    if (!name) {
      createMsg.textContent = "Nama tabungan wajib diisi.";
      createMsg.className = "field-msg error";
      return;
    }
    if (!target || target <= 0) {
      createMsg.textContent = "Target tabungan harus lebih dari 0.";
      createMsg.className = "field-msg error";
      return;
    }
    if (!daily || daily <= 0) {
      createMsg.textContent = "Menabung perhari harus lebih dari 0.";
      createMsg.className = "field-msg error";
      return;
    }

    const goals = loadGoals();
    const createdAt = Date.now();
    const newGoal = {
      id: uid(),
      name,
      image: selectedImageData,
      target,
      dailyAmount: daily,
      days: selectedDays.slice(),
      time: inputTime.value || "",
      createdAt,
      estimatedCompletion: computeEstimatedCompletion(createdAt, target, daily, selectedDays),
      currentTotal: 0,
      history: [],
    };
    goals.unshift(newGoal);
    saveGoals(goals);

    scheduleReminder(newGoal);

    renderHome();
    showScreen(screenHome);
  });

  // ---------- DETAIL SCREEN ----------
  const detailTitle = document.getElementById("detail-title");
  const detailImage = document.getElementById("detail-image");
  const detailCurrent = document.getElementById("detail-current");
  const detailTarget = document.getElementById("detail-target");
  const detailProgressFill = document.getElementById("detail-progress-fill");
  const detailDaily = document.getElementById("detail-daily");
  const detailSchedule = document.getElementById("detail-schedule");
  const detailCreated = document.getElementById("detail-created");
  const detailFinish = document.getElementById("detail-finish");
  const historyBox = document.getElementById("history-box");
  const addAmount = document.getElementById("add-amount");
  const addReason = document.getElementById("add-reason");
  const addMsg = document.getElementById("add-msg");
  const addFundBtn = document.getElementById("add-fund-btn");
  const detailDeleteBtn = document.getElementById("detail-delete-btn");

  let currentGoalId = null;

  attachThousandFormatting(addAmount);

  function openDetail(id) {
    currentGoalId = id;
    renderDetail();
    addAmount.value = "";
    addReason.value = "";
    addMsg.textContent = "";
    addMsg.className = "field-msg";
    showScreen(screenDetail);
  }

  function renderDetail() {
    const goals = loadGoals();
    const g = goals.find((x) => x.id === currentGoalId);
    if (!g) {
      showScreen(screenHome);
      return;
    }

    detailTitle.textContent = g.name;
    detailImage.src = g.image || "";
    detailCurrent.textContent = formatRupiah(g.currentTotal);
    detailTarget.textContent = "/ " + formatRupiah(g.target);

    const pct = g.target > 0 ? Math.min(100, Math.round((g.currentTotal / g.target) * 100)) : 0;
    detailProgressFill.style.width = pct + "%";

    detailDaily.textContent = "Target harian: " + formatRupiah(g.dailyAmount);
    const daysText = g.days && g.days.length ? g.days.join(", ") : "-";
    const timeText = g.time || "-";
    detailSchedule.textContent = daysText + " • " + timeText;

    detailCreated.textContent = formatDateLong(g.createdAt);
    detailFinish.textContent = g.currentTotal >= g.target
      ? formatDateLong(Date.now()) + " (tercapai)"
      : formatDateLong(g.estimatedCompletion);

    // history, terbaru di atas
    historyBox.innerHTML = "";
    if (!g.history || g.history.length === 0) {
      historyBox.innerHTML = '<span class="placeholder">Belum ada riwayat menabung.</span>';
    } else {
      const sorted = g.history.slice().sort((a, b) => b.timestamp - a.timestamp);
      sorted.forEach((h) => {
        const d = new Date(h.timestamp);
        const tanggal = d.toLocaleDateString("id-ID", { day: "2-digit", month: "2-digit", year: "numeric" });
        const hari = DAY_NAMES[d.getDay()];
        const waktu = d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });

        const entry = document.createElement("div");
        entry.className = "history-entry";
        entry.innerHTML = `
          <div class="history-entry-left">
            <div class="history-entry-reason">${escapeHtml(h.reason || "-")}</div>
            <div class="history-entry-time">${hari}, ${tanggal} • ${waktu}</div>
          </div>
          <div class="history-entry-amount">+${formatRupiah(h.amount)}</div>
        `;
        historyBox.appendChild(entry);
      });
    }
  }

  document.getElementById("detail-back-btn").addEventListener("click", () => {
    renderHome();
    showScreen(screenHome);
  });

  addFundBtn.addEventListener("click", () => {
    const amount = parseFormattedNumber(addAmount);
    const reason = addReason.value.trim();

    if (!amount || amount <= 0) {
      addMsg.textContent = "Jumlah uang harus lebih dari 0.";
      addMsg.className = "field-msg error";
      return;
    }

    const goals = loadGoals();
    const g = goals.find((x) => x.id === currentGoalId);
    if (!g) return;

    g.currentTotal = (g.currentTotal || 0) + amount;
    g.history = g.history || [];
    g.history.push({
      id: uid(),
      timestamp: Date.now(),
      amount,
      reason,
    });
    saveGoals(goals);

    addAmount.value = "";
    addReason.value = "";
    addMsg.textContent = "Berhasil ditambahkan.";
    addMsg.className = "field-msg success";

    renderDetail();
  });

  detailDeleteBtn.addEventListener("click", () => {
    if (!confirm("Hapus tabungan ini? Semua history akan hilang.")) return;
    let goals = loadGoals();
    const g = goals.find((x) => x.id === currentGoalId);
    if (g) cancelNativeReminder(g);
    goals = goals.filter((x) => x.id !== currentGoalId);
    saveGoals(goals);
    renderHome();
    showScreen(screenHome);
  });

  // ---------- NOTIFIKASI ----------
  // Ubah string jadi angka positif untuk id notifikasi Capacitor (harus int).
  function hashToId(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
    }
    return (hash % 2000000000) + 1;
  }

  function notificationIdsFor(goal) {
    const days = goal.days && goal.days.length ? goal.days : DAY_NAMES.slice();
    return days.map((d) => hashToId(goal.id + "|" + d));
  }

  // APK (Capacitor Local Notifications) — notifikasi ASLI, tetap muncul
  // walau app ditutup, berulang tiap minggu di hari+jam yang dipilih.
  // Butuh plugin @capacitor/local-notifications (lihat README).
  async function scheduleNativeReminder(goal) {
    const cap = window.Capacitor;
    if (!cap || !cap.Plugins || !cap.Plugins.LocalNotifications || !goal.time) return false;
    const LN = cap.Plugins.LocalNotifications;

    try {
      const perm = await LN.requestPermissions();
      if (perm.display !== "granted") return false;
    } catch (e) {
      return false;
    }

    const [hh, mm] = goal.time.split(":").map(Number);
    const days = goal.days && goal.days.length ? goal.days : DAY_NAMES.slice();

    const notifications = days.map((d) => ({
      id: hashToId(goal.id + "|" + d),
      title: "Waktunya Menabung! 🐷",
      body: 'Jangan lupa menabung untuk "' + goal.name + '" hari ini.',
      schedule: {
        on: { weekday: CAP_WEEKDAY[d], hour: hh, minute: mm },
        allowWhileIdle: true,
      },
    }));

    try {
      await LN.schedule({ notifications });
      return true;
    } catch (e) {
      return false;
    }
  }

  async function cancelNativeReminder(goal) {
    const cap = window.Capacitor;
    if (!cap || !cap.Plugins || !cap.Plugins.LocalNotifications) return;
    try {
      const ids = notificationIdsFor(goal).map((id) => ({ id }));
      await cap.Plugins.LocalNotifications.cancel({ notifications: ids });
    } catch (e) {
      // abaikan
    }
  }

  // Browser biasa — pakai Web Notification API. CATATAN JUJUR: ini cuma
  // bisa muncul selama tab/app ini terbuka di background, karena browser
  // tidak bisa membangunkan sendiri seperti alarm sistem. Untuk notifikasi
  // yang jalan walau app ditutup total, itu perlu jalur native di atas
  // (setelah dibungkus APK dengan plugin Local Notifications).
  function requestBrowserPermission() {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }
  }

  const notifiedThisMinute = new Set();

  function checkBrowserReminders() {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    const goals = loadGoals();
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const nowTime = hh + ":" + mm;
    const todayName = DAY_NAMES[now.getDay()];
    const minuteKey = now.toDateString() + " " + nowTime;

    goals.forEach((g) => {
      if (!g.time || g.time !== nowTime) return;
      const days = g.days && g.days.length ? g.days : DAY_NAMES.slice();
      if (!days.includes(todayName)) return;

      const key = g.id + "|" + minuteKey;
      if (notifiedThisMinute.has(key)) return;
      notifiedThisMinute.add(key);

      try {
        new Notification("Waktunya Menabung! 🐷", {
          body: 'Jangan lupa menabung untuk "' + g.name + '" hari ini.',
        });
      } catch (e) {
        // beberapa browser mobile tidak izinkan new Notification() langsung
      }
    });
  }

  function scheduleReminder(goal) {
    requestBrowserPermission();
    scheduleNativeReminder(goal); // no-op kalau bukan APK/plugin belum ada
  }

  setInterval(checkBrowserReminders, 15000);
  requestBrowserPermission();

  // ---------- INIT ----------
  renderHome();
  showScreen(screenHome);
})();

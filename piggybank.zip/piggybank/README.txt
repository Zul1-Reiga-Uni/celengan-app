CELENGAN — Panduan
====================

ISI FOLDER
----------
index.html   -> semua layar (Home, Buat Tabungan, Detail) dalam 1 file,
                berpindah pakai JavaScript (bukan reload halaman)
css/style.css -> styling (tema blue/cyan, senada dengan app sebelumnya)
js/app.js    -> semua logika: simpan/ambil data, hitung progress, history,
                format angka, notifikasi
assets/video/ -> taruh 1 file video di sini

FILE ASET YANG WAJIB DITAMBAHKAN (nama harus persis)
------------------------------------------------------
assets/video/Backround1.mp4 -> video background di belakang seluruh
                                  layar app, auto-loop, tanpa suara.
                                  Rekomendasi rasio 9:16 (mengikuti bentuk
                                  frame app), video pendek (3-8 detik)
                                  biar ringan dan loop-nya mulus.

Kalau file belum ada, background akan tetap gelap polos — bukan error.

CARA COBA
---------
Buka index.html langsung di browser (double click), atau jalankan lewat
local server (lebih stabil untuk upload gambar besar):
    python3 -m http.server 8080
lalu buka http://localhost:8080/

CARA KERJA DATA
----------------
Semua tabungan disimpan di localStorage HP/browser (tersimpan otomatis,
tidak perlu internet, tidak terkirim ke server manapun). Struktur per
tabungan: nama, gambar (base64), target, menabung per hari, jadwal
(hari+jam), tanggal dibuat, perkiraan tanggal selesai, currentTotal
(total terkumpul), dan history (tanggal, hari, waktu, jumlah, alasan
tiap kali "Tambah Tabungan" ditekan).

FORMAT ANGKA & TANGGAL
-------------------------
- Target Tabungan, Menabung Perhari, dan Uang otomatis diberi titik
  ribuan saat diketik (1000 -> 1.000), tersimpan sebagai angka biasa
  di balik layar.
- "Tabungan dibuat" = tanggal saat tombol Mulai Menabung ditekan.
- "Tabungan selesai" = PERKIRAAN, dihitung otomatis dari target, jumlah
  menabung per hari, dan hari yang dipilih (bukan tanggal pasti, karena
  tergantung kamu benar-benar menabung sesuai jadwal atau tidak).

TENTANG NOTIFIKASI (SUNGGUHAN)
----------------------------------
Ada 2 jalur notifikasi di kode ini, otomatis dipilih sesuai environment:

1. BROWSER BIASA (untuk coba-coba sekarang)
   Pakai Web Notification API bawaan browser. JUJUR SOAL BATASANNYA:
   ini HANYA bisa muncul selama tab/app ini masih terbuka (boleh di
   background/minimized, tapi tidak boleh benar-benar ditutup), karena
   browser tidak bisa "membangunkan diri sendiri" seperti alarm sistem.
   Browser akan minta izin notifikasi saat pertama kali dibuka — izinkan
   supaya fitur ini aktif.

2. APK — NOTIFIKASI ASLI, JALAN WALAU APP DITUTUP TOTAL
   Ini yang benar-benar "notifikasi sungguhan" seperti alarm HP biasa.
   Butuh plugin Capacitor Local Notifications:

   1. npm install @capacitor/local-notifications
   2. npx cap sync android
   3. Build ulang APK.

   Setelah plugin ini aktif, tiap kali tabungan baru dibuat dengan jam
   yang diisi, notifikasi otomatis dijadwalkan untuk berulang tiap
   minggu di hari+jam yang dipilih — sistem Android sendiri yang
   membangunkan notifikasinya, bukan JavaScript, jadi tetap muncul
   walau app sudah ditutup dari recent apps.

CARA MENGUBAH INI MENJADI FILE .APK
-------------------------------------
Ada 2 jalur:

A) PAKAI KOMPUTER (Node.js + Android Studio) — lihat panduan Capacitor
   standar (npm install @capacitor/core @capacitor/cli, npx cap init,
   npx cap add android, dst).

B) PURE HP, TANPA KOMPUTER — pakai GitHub Actions (server GitHub yang
   build APK-nya, bukan HP kamu). File workflow-nya SUDAH DISERTAKAN di
   folder .github/workflows/build.yml di dalam zip ini.

   Langkah:
   1. Install app Termux di HP (dari F-Droid/Play Store).
   2. Buat akun & repository baru di github.com lewat browser HP.
   3. Di Termux:
        pkg update && pkg install git
        termux-setup-storage
        cd storage/downloads/<folder-hasil-unzip-project-ini>
        git init
        git add .
        git commit -m "initial"
        git branch -M main
        git remote add origin https://github.com/USERNAME/NAMA-REPO.git
        git push -u origin main
      Saat diminta login, pakai Personal Access Token (buat di GitHub:
      Settings > Developer settings > Personal access tokens > Generate
      new token, centang scope "repo"), bukan password akun biasa.
   4. Push otomatis memicu GitHub Actions untuk build APK. Buka tab
      "Actions" di repo kamu lewat browser HP, tunggu sampai selesai
      (tanda centang hijau).
   5. Buka run yang selesai itu, scroll ke bagian "Artifacts", unduh
      "celengan-apk" — isinya file app-debug.apk, langsung install ke HP
      (aktifkan dulu "Izinkan instal dari sumber tidak dikenal" di
      pengaturan HP).

   Setiap kali kode diubah, ulangi: git add . && git commit -m "update"
   && git push — build APK baru otomatis jalan lagi di GitHub.

   CATATAN: file APK dari cara ini adalah versi DEBUG (untuk dites di HP
   sendiri), belum untuk dipublish ke Play Store — itu proses signing
   terpisah, beda topik lagi kalau nanti sampai situ.
